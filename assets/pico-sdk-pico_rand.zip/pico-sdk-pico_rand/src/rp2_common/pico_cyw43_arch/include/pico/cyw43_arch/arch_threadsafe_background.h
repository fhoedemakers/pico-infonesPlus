/*
 * Copyright (c) 2022 Raspberry Pi (Trading) Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef _PICO_CYW43_ARCH_ARCH_THREADSAFE_BACKGROUND_H
#define _PICO_CYW43_ARCH_ARCH_THREADSAFE_BACKGROUND_H

#include "pico/cyw43_arch/arch_common.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif